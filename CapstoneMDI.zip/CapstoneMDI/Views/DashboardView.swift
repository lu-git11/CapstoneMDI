//
//  DashboardView.swift
//  CapstoneMDI
//
//  Created by jeffrey lullen on 8/11/26.
//

import SwiftUI

struct DashboardView: View {
    
    
    @State private var taskGroups : [DashboardGroup] = []  //= TaskGroup.sampleData
    @State private var selectedGroup: DashboardGroup?
    @State private var isShowingAddGroup = false
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack{
            ZStack {
                Background.gradient3.ignoresSafeArea()
                List(selection: $selectedGroup) {
                    NavigationLink(destination: WorkoutView()) {
                        
                        
                        HStack(spacing: 20) {
                            
                            Image(systemName: "house.fill")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                                .frame(width: 35, height: 35)
                                .background(.blue.gradient, in: RoundedRectangle(cornerRadius: 8))
                            
                            Text ("Workouts")
                            
                            Spacer()
                        }
                        .padding(.vertical, 5)
                    }
                }
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button {
                            isShowingAddGroup = true
                        } label: {
                            Image(systemName: "plus")
                        }
                    }
                }
                .sheet(isPresented: $isShowingAddGroup) {
                    NewDashboardView { newGroup in
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8))
                            .append(newGroup)
                        selectedGroup = newGroup
                    }
                }
                .listStyle(.sidebar)
                .scrollContentBackground(.hidden)
            }
        }
    }
}

#Preview("Dashboard") {
    DashboardView()
}

